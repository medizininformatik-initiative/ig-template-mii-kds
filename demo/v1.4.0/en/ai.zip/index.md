# Home - MII KDS IG Template — Preview v1.4.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://github.com/medizininformatik-initiative/ig-template-mii-kds/ImplementationGuide/de.medizininformatikinitiative.template.preview | *Version*:1.4.0 |
| Draft as of 2026-11-26 | *Computable Name*:MIIKDSTemplatePreview |

This page exists solely for the **preview** of the `de.medizininformatikinitiative.template` IG template. It is **not** an MII Core Dataset module.

The preview builds the template standalone so that branding changes (header, footer, CSS, logo) can be reviewed in a rendered IG before a template version is released. The build renders in English (the default language) and German, to check the language-aware header and footer.

What the template is and how a module uses it is described in the repository's `README.md`.

The template also contributes one page to every guide it renders: [Validate an instance](validate.md) — the Simplifier-substitute for checking an implementer's own FHIR instance against the module (also linked in the footer). This preview shows it with the preview's own package preset.

### Highlight boxes (background-colour demo)

The template ships reusable, purpose-neutral CSS classes for calling out content (classes `ig-highlight` with `-blue`, `-green`, `-orange`, `-red`, `-grey`). These are styling only — a module decides what each colour means; the conventional reading is orange = warning, red = important, grey = hint.

#### Blue highlight box

Example of the blue background highlight (`ig-highlight-blue`).

#### Green highlight box

Example of the green background highlight (`ig-highlight-green`).

#### Orange highlight box (warning)

Example of the orange background highlight (`ig-highlight-orange`) — conventionally a warning.

#### Red highlight box (important)

Example of the red background highlight (`ig-highlight-red`) — conventionally an important notice.

#### Grey highlight box (hint)

Example of the grey background highlight (`ig-highlight-grey`) — conventionally a hint or authoring note.


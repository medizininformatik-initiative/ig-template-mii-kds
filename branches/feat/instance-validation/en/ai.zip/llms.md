# de.medizininformatikinitiative.template.preview#1.3.4: MII KDS IG Template — Preview(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Translation information](translationinfo.md)
* [](validate.md)

## Resources

### Logicals

* [Preview Model](StructureDefinition-preview-model.md)

### Resource Profiles

* [Preview Patient](StructureDefinition-preview-patient.md)

### ImplementationGuides

* [MII KDS IG Template — Preview](ImplementationGuide-de.medizininformatikinitiative.template.preview.md)
